X-Wing series 60FPS (1.0.2) patch by Justagai

This will change the FPS limit from 30 to 60 in any of the X-Wing games in the series: X-Wing, TIE Fighter, X-Wing vs TIE Fighter, Balance of power and X-Wing Alliance

Compatible with the Disc, GoG and Steam versions.


Instructions: Extract/Move dinput.dll and Hook_60FPS.dll into the game folder.

Multiplayer: Make sure that everyone has the same patch installed to prevent syncing issues.

Notes: 

- If there is a frame loss when targeting something and you have a custom DDRAW installed, try turning off antialiasing in its config.

Issues:

- It is possible that 60FPS can make some missions impossible due to a movement bug in the engine. Please report the mission with the bugged craft.

Changelog:

1.0.2
- XWA: Hangar is now 60FPS

1.0.1
- Fixed issue with certain machines crashing at game startup

1.0
- Initial version


Special thanks to:
JeremyaFr (Originally created the hooks which this patch is based off of)
RandomStarfighter (Overall help with everything)
XWVM team (Lots of engine knowledge discovered)

And thanks to all who helped test!
